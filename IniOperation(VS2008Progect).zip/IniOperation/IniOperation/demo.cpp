/*
* show how to used the ini operate methods
*/

#include "Ini.h"
#include <iostream>
using namespace std;

int main(void)
{
	CIni cIni("D:/iniTest.ini");

	// set values
	CString sNode = "TestNode"; // node name
	cIni.SetInt(sNode, "IntKey", -123);
	cIni.SetDouble(sNode, "DoubleKey", 123.0987);
	cIni.SetFloat(sNode, "FloatKey", -56.2f);
	cIni.SetCstring(sNode, "CStringKey", CString("hello, ini!"));
	cIni.SetPchar(sNode, "PcharKey", "Can you feel me?");

	// get key values
	cout << "show key values:" << endl;
	cout << "IntKey = " << cIni.GetInt(sNode, "IntKey") << endl;
	cout << "DoubleKey = " << cIni.GetDouble(sNode, "DoubleKey") << endl;
	cout << "FloatKey = " << cIni.GetFloat(sNode, "FloatKey") << endl;
	cout << "CStringKey = " << cIni.GetCString(sNode, "CStringKey") << endl;
	CString str = cIni.GetCString(sNode, "PcharKey");
	char *pch = (LPSTR)(LPCTSTR)str;
	cout << "PcharKey = " << pch << endl;

	return 0;
}